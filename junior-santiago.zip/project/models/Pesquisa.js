// models/Pesquisa.js
const mongoose = require('mongoose');

const RespostaSchema = new mongoose.Schema({
  satisfacaoProduto: Number,
  atendimento: Number,
  avaliacaoEntrega: Number,
  avaliacaoMontagem: Number,
  voltaria: Boolean,
  usuario: String,
  dataResposta: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Resposta', RespostaSchema);
