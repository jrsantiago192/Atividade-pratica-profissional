const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Resposta = require('./models/Pesquisa');
const User = require('./models/Usuario');
const ExcelJS = require('exceljs');
const http = require('http');

const app = express();
const server = http.createServer(app);
const SECRET_KEY = 'secret';

app.use(cors());
app.use(express.json());
app.use(express.static('views'));

mongoose.connect('mongodb://root:pass@172.18.0.1:27017/pesquisa', {
  authSource: "admin"
});

function authenticateToken(req, res, next) {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).send('Acesso negado');
  
  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.status(403).send('Token inválido');
    req.user = user;
    next();
  });
}

app.post('/api/cadastro', async (req, res) => {
  const { nome, email, senha } = req.body;

  const usuarioExistente = await User.findOne({ email });
  if (usuarioExistente) {
    return res.status(400).json({ message: 'Usuário já existe!' });
  }

  const senhaHash = await bcrypt.hash(senha, 10);

  const novoUsuario = new User({ nome, email, senha: senhaHash });
  await novoUsuario.save();

  res.status(201).json({ message: 'Usuário cadastrado com sucesso!' });
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ email: username });
  if (!user || !(await bcrypt.compare(password, user.senha))) {
    return res.status(400).send('Credenciais inválidas');
  }
  const token = jwt.sign({ username: user.nome }, SECRET_KEY, { expiresIn: '1h' });
  res.json({ token, username: user.nome });
});

app.post('/api/respostas', authenticateToken, async (req, res) => {
  const novaResposta = new Resposta(req.body);

  await novaResposta.save();
  res.status(201).send('Resposta registrada');
});

app.get('/api/respostas', authenticateToken, async (req, res) => {
  try {
    const respostas = await Resposta.find();
    res.json(respostas);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar respostas' });
  }
});

app.get('/api/export', async (req, res) => {
  const respostas = await Resposta.find();
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Respostas');

  worksheet.columns = [
    { header: 'Satisfação Produto', key: 'satisfacaoProduto' },
    { header: 'Atendimento', key: 'atendimento' },
    { header: 'Avaliação Entrega', key: 'avaliacaoEntrega' },
    { header: 'Avaliação Montagem', key: 'avaliacaoMontagem' },
    { header: 'Voltaria', key: 'voltaria' },
    { header: 'Usuario', key: 'usuario' },
    { header: 'Data da Resposta', key: 'dataResposta' }
  ];

  respostas.forEach(resposta => worksheet.addRow(resposta.toObject()));

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="pesquisa_respostas.xlsx"');

  await workbook.xlsx.write(res);
});

app.get('/api/media', authenticateToken, async (req, res) => {
  try {
    const media = await Resposta.aggregate([
      {
        $group: {
          _id: null,
          satisfacaoProduto: { $avg: "$satisfacaoProduto" },
          atendimento: { $avg: "$atendimento" },
          avaliacaoEntrega: { $avg: "$avaliacaoEntrega" },
          avaliacaoMontagem: { $avg: "$avaliacaoMontagem" }
        }
      }
    ]);

    if (media.length === 0) {
      return res.json({
        satisfacaoProduto: 0,
        atendimento: 0,
        avaliacaoEntrega: 0,
        avaliacaoMontagem: 0
      });
    }

    res.json({
      satisfacaoProduto: media[0].satisfacaoProduto.toFixed(2),
      atendimento: media[0].atendimento.toFixed(2),
      avaliacaoEntrega: media[0].avaliacaoEntrega.toFixed(2),
      avaliacaoMontagem: media[0].avaliacaoMontagem.toFixed(2)
    });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao calcular médias' });
  }
});

server.listen(3000, () => console.log('Server is running on http://localhost:3000'));
